<?php

require_once 'ConexaoMysql.php';

class usuariosModel {

    //Atributos ou propriedades
    protected $id;
    protected $nome;
    protected $email;
    protected $senha;
    protected $dataNasc;

    //Métodos acessores (get) e modificadores (set)
    public function getId() {
        return $this->id;
    }
    public function getNome() {
        return $this->nome;
    }
    public function getEmail() {
        return $this->email;
    }
    public function getSenha() {
        return $this->senha;
    }
    public function getDataNasc() {
        return $this->dataNasc;
    }
    public function setId($id): void {
        $this->id = $id;
    }
    public function setNome($nome): void {
        $this->nome = $nome;
    }
    public function setEmail($email): void {
        $this->email = $email;
    }
    public function setSenha($senha): void {
        $this->senha = $senha;
    }
    public function setDataNasc($dataNasc): void {
        $this->dataNasc = $dataNasc;
    }
    //Método construtor
    public function __construct() {
        
    }
    //Métodos especialistas
    public function loadAll() {

        //Criar um objeto de conexão
        $db = new ConexaoMysql();

        //Abrir conexão com banco de dados
        $db->Conectar();

        //Criar consulta
        $sql = 'SELECT * FROM usuarios';
        //Executar método de consulta
        $resultList = $db->Consultar($sql);

        //Desconectar do banco
        $db->Desconectar();

        return $resultList;
    }
    public function login($email, $senha) {
        //Criar um objeto de conexão
        $db = new ConexaoMysql();

        //Abrir conexão com banco de dados
        $db->Conectar();

        //Criar consulta
        $sql = 'SELECT * FROM usuarios where email="' . $email . '"  AND  senha="' . md5($senha) . '"';

        //Executar método de consulta
        $db->Executar($sql);
        //Desconectar do banco
        $db->Desconectar();

        return $db->total;
    }
    public function takeName($email, $senha) {
        //Criar um objeto de conexão
        $db = new ConexaoMysql();

        //Abrir conexão com banco de dados
        $db->Conectar();

        //Criar consulta
        $sql = 'SELECT * FROM usuarios where email="' . $email . '"  AND  senha="' . md5($senha) . '"';

        //Executar método de consulta
        $resultList = $db->Consultar($sql);
        
        foreach($resultList as $user){
            $this->id = $user['id']; 
        }
        
        //Desconectar do banco
        $db->Desconectar();

        return 0;
    }
    public function insert() {//Criar um objeto de conexão
        $db = new ConexaoMysql();
//Abrir conexão com banco de dados
        $db->Conectar();
//Criar consulta
        $this->senha = md5($this->senha);
        $sql = 'INSERT INTO usuarios values (0,
                "' . $this->nome . '",
                "' . $this->email . '",
                "' . $this->senha . '",
                "' . $this->dataNasc . '")';
//Executar método de inserção
        $db->Executar($sql);
//Desconectar do banco
        $db->Desconectar();
        $total=$db->total;
        return $total;
    }
    public function update() {
        //Criar um objeto de conexão
        $db = new ConexaoMysql();
        //Abrir conexão com banco de dados
        $db->Conectar();
        $sql = 'UPDATE usuarios SET '
                . 'nome="' . $this->nome . '",'
                . 'email="' . $this->email . '",'
                . 'senha ="' . md5($this->senha) . '",'
                . 'dataNasc ="' . $this->dataNasc . '"'
                . 'WHERE id = ' . $this->id;
        //Executar método de inserção
        $db->Executar($sql);
        //Desconectar do banco
        $db->Desconectar();
        return $db->total;
    }
    public function delete() {

        //Criar um objeto de conexão
        $db = new ConexaoMysql();

        //Abrir conexão com banco de dados
        $db->Conectar();

        //$sql = 'DELETE FROM usuarios WHERE id=';
        $sql = 'DELETE FROM usuarios WHERE id=' . $this->id;

        //Executar método de inserção
        $db->Executar($sql);

        //Desconectar do banco
        $db->Desconectar();

        return $db->total;
    }
}