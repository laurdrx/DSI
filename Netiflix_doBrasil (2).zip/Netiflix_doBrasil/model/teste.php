<?php
require_once("ConexaoMysql.php");

$conexao = new ConexaoMysql();

$conexao->Conectar();

if ($conexao->getConnection()->connect_errno){
    echo "errouu";
}

    else{
    echo "deuu";
        
    }
    $conexao->Desconectar();
    ?>