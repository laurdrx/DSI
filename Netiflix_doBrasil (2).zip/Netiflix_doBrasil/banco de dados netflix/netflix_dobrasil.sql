-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 17-Out-2023 às 14:31
-- Versão do servidor: 8.0.30
-- versão do PHP: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `netflix_dobrasil`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `categorias`
--

DROP TABLE IF EXISTS `categorias`;
CREATE TABLE IF NOT EXISTS `categorias` (
  `id` int NOT NULL,
  `nome` varchar(45) NOT NULL,
  `descricao` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estrutura da tabela `filmes`
--

DROP TABLE IF EXISTS `filmes`;
CREATE TABLE IF NOT EXISTS `filmes` (
  `id` int NOT NULL,
  `nome` varchar(45) NOT NULL,
  `categorias_id` int NOT NULL,
  `imagem` varchar(45) NOT NULL,
  `categorias_id1` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_filmes_categorias_idx` (`categorias_id1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estrutura da tabela `filmes_has_perfis`
--

DROP TABLE IF EXISTS `filmes_has_perfis`;
CREATE TABLE IF NOT EXISTS `filmes_has_perfis` (
  `filmes_id` int NOT NULL,
  `perfis_id` int NOT NULL,
  `perfis_usuários_id` int NOT NULL,
  PRIMARY KEY (`filmes_id`,`perfis_id`,`perfis_usuários_id`),
  KEY `fk_filmes_has_perfis_perfis1_idx` (`perfis_id`,`perfis_usuários_id`),
  KEY `fk_filmes_has_perfis_filmes1_idx` (`filmes_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estrutura da tabela `perfis`
--

DROP TABLE IF EXISTS `perfis`;
CREATE TABLE IF NOT EXISTS `perfis` (
  `id` int NOT NULL,
  `nome` varchar(45) NOT NULL,
  `imagem` varchar(45) NOT NULL,
  `tipo` varchar(15) NOT NULL,
  `usuários_id` int NOT NULL,
  `usuário_id` int NOT NULL,
  PRIMARY KEY (`id`,`usuários_id`),
  KEY `fk_perfis_usuário1_idx` (`usuário_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuário`
--

DROP TABLE IF EXISTS `usuário`;
CREATE TABLE IF NOT EXISTS `usuário` (
  `id` int NOT NULL,
  `nome` varchar(200) DEFAULT NULL,
  `email` varchar(20) NOT NULL,
  `senha` varchar(20) NOT NULL,
  `dataNasc` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `filmes`
--
ALTER TABLE `filmes`
  ADD CONSTRAINT `fk_filmes_categorias` FOREIGN KEY (`categorias_id1`) REFERENCES `categorias` (`id`);

--
-- Limitadores para a tabela `filmes_has_perfis`
--
ALTER TABLE `filmes_has_perfis`
  ADD CONSTRAINT `fk_filmes_has_perfis_filmes1` FOREIGN KEY (`filmes_id`) REFERENCES `filmes` (`id`),
  ADD CONSTRAINT `fk_filmes_has_perfis_perfis1` FOREIGN KEY (`perfis_id`,`perfis_usuários_id`) REFERENCES `perfis` (`id`, `usuários_id`);

--
-- Limitadores para a tabela `perfis`
--
ALTER TABLE `perfis`
  ADD CONSTRAINT `fk_perfis_usuário1` FOREIGN KEY (`usuário_id`) REFERENCES `usuário` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
