<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <script src="js/jquery-3.7.1.min.js" type="text/javascript"></script>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
        <script src="js/jquery.dataTables.min.js" type="text/javascript"></script>
        <link href="CSS/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="CSS/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <link href="CSS/styleUsuario.css" rel="stylesheet" type="text/css"/>
    <body>
        <div class="logo">
            <img src="https://i.ibb.co/r5krrdz/logo.png">
        </div>
        <div class="container mt-3">
            <div class="container mt-3">
                <table id="usuariosTable" class="table table-bordered">
                    <thead>
                    <th>Id</th>
                    <th>Email</th>
                    <th>Senha</th>

                    </thead>
                    <tbody>
                        <?php
                        require_once './controller/cadastroController.php';
                        $usuariosList = loadAll();
                        //Exibir resultado
                        foreach ($usuariosList as $usuarios) {
                            echo'<tr><td>' . $usuarios["id"] . '</td><td>' . $usuarios["email"] . '</td><td>' . $usuarios["senha"] . '</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
                <a href="loginPage.php" class="btn-back">Voltar para a página inicial</a>
            </div>
        </div>
        <script>
            $(document).ready(function () {
            $('#usuariosTable').DataTable({

            });
        </script>
    </body>
</html>
