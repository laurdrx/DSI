<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Cadastro de usuários</title>
        <link href="CSS/styleCadastro.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery-3.7.1.min.js" type="text/javascript"></script>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
        
    </head>
    <body>
            <div class="logo">
                <a href="loginPage.php">
                <img src="https://i.ibb.co/r5krrdz/logo.png">
                </a>
            </div>
        <form method="post" action="controller/cadastroController.php">
            <div class="container">
                <h1>Cadastro de usuários</h1>
                <input type="hidden" name="id">
                <div class="form-group">
                    <label for="nome">Nome:</label>
                    <input type="text" class="form-control" id="nome" name="nome"  required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="text" class="form-control" id="email" name="email"  required>
                </div> 
                
               <div class="form-group">
                    <label for="senha">Senha:</label>
                    <input type="password" class="form-control" id="senha" name="senha"  required>
                </div> 
                <div class="form-group">
                    <label for="dataNasc">Data de nascimento:</label>
                    <input type="date" class="form-control" id="dataNasc" name="dataNasc"  required>
                </div> 
                <br>
                <input type="submit" class="btn btn-success" value="Salvar">
            </div>
        </form>
    </body>
</html>
