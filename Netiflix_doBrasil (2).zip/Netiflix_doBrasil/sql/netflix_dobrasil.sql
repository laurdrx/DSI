-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema netflix_dobrasil
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema netflix_dobrasil
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `netflix_dobrasil` DEFAULT CHARACTER SET utf8mb3 ;
USE `netflix_dobrasil` ;

-- -----------------------------------------------------
-- Table `netflix_dobrasil`.`categorias`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `netflix_dobrasil`.`categorias` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `descricao` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb3;


-- -----------------------------------------------------
-- Table `netflix_dobrasil`.`usuarios`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `netflix_dobrasil`.`usuarios` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(200) NULL DEFAULT NULL,
  `email` VARCHAR(20) NOT NULL,
  `senha` VARCHAR(250) NOT NULL,
  `dataNasc` DATE NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb3;


-- -----------------------------------------------------
-- Table `netflix_dobrasil`.`perfis`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `netflix_dobrasil`.`perfis` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `imagem` VARCHAR(45) NOT NULL,
  `tipo` VARCHAR(15) NOT NULL,
  `usuarios_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_perfis_usuarios1_idx` (`usuarios_id` ASC) VISIBLE,
  CONSTRAINT `fk_perfis_usuarios1`
    FOREIGN KEY (`usuarios_id`)
    REFERENCES `netflix_dobrasil`.`usuarios` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb3;


-- -----------------------------------------------------
-- Table `netflix_dobrasil`.`filmes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `netflix_dobrasil`.`filmes` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `imagem` VARCHAR(45) NOT NULL,
  `perfis_id` INT NOT NULL,
  `categorias_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_filmes_perfis1_idx` (`perfis_id` ASC) VISIBLE,
  INDEX `fk_filmes_categorias1_idx` (`categorias_id` ASC) VISIBLE,
  CONSTRAINT `fk_filmes_perfis1`
    FOREIGN KEY (`perfis_id`)
    REFERENCES `netflix_dobrasil`.`perfis` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_filmes_categorias1`
    FOREIGN KEY (`categorias_id`)
    REFERENCES `netflix_dobrasil`.`categorias` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb3;


-- -----------------------------------------------------
-- Table `netflix_dobrasil`.`filmes_has_perfis`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `netflix_dobrasil`.`filmes_has_perfis` (
  `filmes_id` INT NOT NULL,
  `perfis_id` INT NOT NULL,
  PRIMARY KEY (`filmes_id`, `perfis_id`),
  INDEX `fk_filmes_has_perfis_perfis1_idx` (`perfis_id` ASC) VISIBLE,
  INDEX `fk_filmes_has_perfis_filmes1_idx` (`filmes_id` ASC) VISIBLE,
  CONSTRAINT `fk_filmes_has_perfis_filmes1`
    FOREIGN KEY (`filmes_id`)
    REFERENCES `netflix_dobrasil`.`filmes` (`id`),
  CONSTRAINT `fk_filmes_has_perfis_perfis1`
    FOREIGN KEY (`perfis_id`)
    REFERENCES `netflix_dobrasil`.`perfis` (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb3;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;