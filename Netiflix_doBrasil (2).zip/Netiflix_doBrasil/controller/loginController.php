<?php
if ($_POST) {// varifica se o usuário preencheu o campo com email e senha
      $email = $_POST['email'];
      $senha = $_POST['password'];
      @$lembrar = $_POST['lembrar'];
      
      require_once '../Model/usuariosModel.php';
      $usuario = new usuariosModel();
      $result = $usuario->login($email, $senha);
      
      if($result){
          session_start();
          
          $usuario->takeName($email, $senha);
          
          $_SESSION['id'] = $usuario->getId();
          $_SESSION['login'] = $email;
          
          if(isset ($lembrar)){
              if($lembrar == 1){ //vai criar o cookie
                  setcookie('email',$email, time()+ (86400 *30),"/");
                 
              }
          }else{// se não tiver marcado checkbox destroi o cookie
              if(isset($cookie)){
                  setcookie('email',"", time()- (86400 *30),"/");
             
              }
              
          }
          
          
          header('location:../perfil.php');
          
      }else{
          header('location:../loginPage.php?cod=171');
      }
  } else {// Se não houver uma solicitação HTTP POST

      header('location:../loginPage.php');// Redireciona de volta para a página inicial
  }

  ?>
