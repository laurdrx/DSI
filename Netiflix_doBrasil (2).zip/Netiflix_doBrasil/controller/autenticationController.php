
<?php
//Inicia a sessão, se ainda não estiver iniciada
session_start();

if(!isset($_SESSION['login'])) {// Verifica se a variável de sessão 'login' não está definida
      header('location:loginPage.php?cod=172');// Redireciona o usuário para a página de login com um código de erro (172)
}

?>