<?php

if ($_POST) {
    require_once '../model/usuariosModel.php';
    $usuarios = new usuariosModel();
    $usuarios->setNome($_POST['nome']);
    $usuarios->setEmail($_POST['email']);
    $usuarios->setSenha($_POST['senha']);
    $usuarios->setDataNasc($_POST['dataNasc']);
    //Configuro o id do objeto.
    $usuarios->setId($_POST['id']); //se for um novo registro vai ser sempre ''
    //Se a variável id que vier do form for vazia '' então insere um novo registro
    //Chamo para ver se o id do objeto é vazio.
    if(empty($usuarios->getId())){
        //Insere um novo registro
        $total = $usuarios->insert();
    } else {
        //Atualiza o registro existente.
        $total = $usuarios->update();
    }
    if ($total == 1) {
        //Se estiver inserindo um novo registro somente exibo  a msg.
        if (empty($usuarios->getId())) {
            header('location:../cadastrarUsuariosPage.php?cod=success');
        } else {
            //Atualizei e foi um sucesso
            header('location:../listarUsuariosPage.php?cod=success');
        }
        
    } else {
      header('location:../cadastrarUsuariosPage.php?cod=error');
    }
} else if ($_REQUEST) {
    //Se existir a query string cod e cod == del
    if (isset($_REQUEST['cod']) && $_REQUEST['cod'] == 'del') {
        //Importa a model
        require_once '../model/usuariosModel.php';
        //Cria o objeto usuarios
        $usuarios = new usuariosModelModel();
        //Se o comando for par excluir
        if (isset($_REQUEST['id']) && !empty($_REQUEST['id'])) {
            //configuro o id
            $usuarios->setId($_REQUEST['id']);
            //exclui em seguida
            $total = $usuarios->delete();
            if ($total == 1) {
                //header('location:../listarUsuariosPage.php?cod=success');
            }
        }
    }
} else {
    //Selecionar todos os registros
    loadAll();
}

function loadAll() {
    //Importo usuarios model
    require_once './model/usuariosModel.php';
    //Crio um objeto do tipo usuarios
    $usuarios = new usuariosModel();
    $resutList = $usuarios->loadAll();

    return $resutList;
}

function loadById($id) {
    //Importo usuarios model
    require_once '../model/usuariosModel.php';
    //Crio um objeto do tipo usuarios
    $usuarios = new usuariosModel();

    //Executa o método para carregar por id
    $usuarios->loadById($id);

    //Retorna um objeto do tipo usuarios.... 
    return $usuarios;
}