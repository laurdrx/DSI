<!DOCTYPE html>
<html lang="pt-br">
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="CSS/style.css">
<title></title>
</head>

    <style>
    </style>

<body>
    <header class="showcase">
        

            <div class="logo">
                <img src="https://i.ibb.co/r5krrdz/logo.png">
            </div>

            <div class="container">
            <div class="showcase-content">
                <div class="formm">

                    <form method="post" action="controller/loginController.php">
                        <h1>Entrar</h1>

                        <div class="row">
                            <div class="col-md-12 text-center">
                            <div class="info">
                                
                                    <div class="mb-1 mt-3">
                                     <?php
                                         // Verifica se o cookie '' existe
                                        if(isset($_COOKIE['email'])){
                                            echo'<input value="'.$_COOKIE['email'].'"class="email" name="email" type="email" placeholder="Email ou numero de telefone">';
                                        }else{
                                            echo'<input class="email" name="email" type="email" placeholder="Email ou numero de telefone">';
                                        }
                                        ?>
                                        <?php
                                            @$cod = $_REQUEST['cod'];// Obtém o valor do parâmetro 'cod' da solicitação, suprimindo possíveis erros
                                            if(isset($cod))
                                            {
                                                if($cod == '171') {  // Verifica se 'cod' está definido
                                                    echo ('<span class="ErroEmail">Verifique usuário.</span>');// Exibe uma mensagem de erro para verificar o usuário
                                                } 
                                            }
                                        ?>
                                    <input class="email" name="password" type="password" placeholder="Senha"><!-- Cria um campo de senha no formulário -->

                                    <?php
                                    // Obtém o valor do parâmetro 'cod' da solicitação novamente, suprimindo possíveis erros
                                    @$cod = $_REQUEST['cod'];
                                    if(isset($cod))// Verifica se 'cod' está definido
                                    {
                                        if($cod == '171') {
                                            echo ('<span class="ErroSenha">Verifique sua senha.</span>');
                                        }
                                    }
                    
                                    ?>
                            </div>
                        
                    </div>
                            
                    </div>

                        <div class="btn">
                            <button class="btn-primary" type="submit">Entrar</button>
                        </div>
                        </div>
                        

                        <div class="help">
                            <div>
                                <?php
                                
                        if (isset($_COOKIE['email'])) {
                            
                            echo ('<input type="checkbox" class="form-check-input" id="lembrar" 
                           name="lembrar" checked value="1">');
                    } else {
                            echo ('<input type="checkbox" class="form-check-input" id="lembrar" 
                            name="lembrar" value="1">');
                    }
                    
                    ?>
                                <label for="Lembrar" class="form-check-label" >Lembre de mim</label>
                                
                            </div>

                            <a href="">Precisa de ajuda?</a>
                             
     
                            <a href="cadastrarUsuariosPage.php">Cadastre-se</a>
                        
                        </div>

                    </form>
    
                </div>
                
                <div class="signup">
                    <p>Novo na por aqui?<a>Assine agora.</a></p>
                    
                </div>
                <div class="more">
                    <p>
                        Esta página é protegida pelo Google reCAPTCHA para garantir que você não seja um bot. <a href="#">Saber mais.</a> 
                    </p>
                </div>


            </div>
            </div>

    </header>


</body>
</html>



